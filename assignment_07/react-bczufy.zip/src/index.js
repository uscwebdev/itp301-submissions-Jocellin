import React from 'react';
import { createRoot } from 'react-dom/client';
import ShoppingCart from "./ShoppingCart.js";
import './index.css';

const root = createRoot(document.querySelector("#root"));

root.render(
<React.StrictMode>
<body>  
<div id="header">
<h1>My Shopping Cart</h1>
</div>

<div id="gallery">

<ShoppingCart
itemsrc="https://image-cdn.hypb.st/https%3A%2F%2Fhypebeast.com%2Fimage%2F2023%2F04%2Ftyler-the-creator-golf-wang-wolf-10th-anniversary-merch-collection-release-info-1.jpg?cbr=1&q=90"
itemcaption="Golf Hoodie"
quantity="100"
/>

<ShoppingCart
itemsrc="https://golfwangofficial.com/wp-content/uploads/2020/11/H3fbfc2066d4b42fba18aafe5d8f29c6f5.jpg"
itemcaption="Golf Shirt"
quantity="80"
/>

<ShoppingCart
itemsrc="https://i.pinimg.com/originals/49/d8/81/49d881dea9d31ab2b6ec1731cc8e1d98.jpg"
itemcaption="Golf Hat"
quantity="55"
/>

<ShoppingCart
itemsrc="https://images.vestiairecollective.com/cdn-cgi/image/w=1246,q=70,f=auto,/produit/multicolour-cotton-golf-wang-knitwear-sweatshirt-34023381-1_3.jpg"
itemcaption="Golf vest"
quantity="60"
/>

{/*}
<div className="container">
<img class="image-size" src="https://image-cdn.hypb.st/https%3A%2F%2Fhypebeast.com%2Fimage%2F2023%2F04%2Ftyler-the-creator-golf-wang-wolf-10th-anniversary-merch-collection-release-info-1.jpg?cbr=1&q=90" alt="golfshirt" id="item-1"/>
<p>Golf Hoodie<br/>$<span id="count1">100</span></p>
</div>

<div className="container">
<img class="image-size" src="https://golfwangofficial.com/wp-content/uploads/2020/11/H3fbfc2066d4b42fba18aafe5d8f29c6f5.jpg" alt="golfshirt" id="item-2"/>
<p>Golf Shirt<br/>$<span id="count2">80</span></p>
</div>

<div className="container">
<img className="image-size" src="https://i.pinimg.com/originals/49/d8/81/49d881dea9d31ab2b6ec1731cc8e1d98.jpg" alt="golfhat" id="item-3"/>
<p>Golf Hat<br/>$<span id="count3">55</span></p>
</div>

</div>

<div className="clearfloat"></div>

<div id="content">
<p><strong>Cart Subtotal:</strong>$<span id="totalcount">0</span></p>
</div>

<div id="footer">
<p>The GOLF shop 2023</p>	
*/}
<div className="clearfloat"></div>
<div id="content">
<p><strong>Cart Subtotal:</strong>$<span id="totalcount">0</span></p>
</div>
<div id="footer">
<p>The GOLF shop 2023</p>	
</div>
</div>
</body>






</React.StrictMode>
);
