import React from 'react';


export default function ShoppingCart(props){
  const [count,setCount] = useState(0);

  const handleMinusClick = () => {
    if (count > 0) {
      setCount(count - 1);
        }
  }

  const handleAddClick = () => {
    setCount(count + 1);
  }
  return(
    <div className="container">
    <img class="image-size" src={props.itemsrc} alt={props.itemsrc + ' Clothing Merch '} id="item-1"/>
    <p>{props.itemcaption}<br/>$<span id="count1">{props.quantity}</span></p>
    <button onClick={handleMinusClick}>-</button><p>0</p>
    <span>{count}</span>
    <button onCLick={handleAddClick}>+</button>
    </div>   


  )
}