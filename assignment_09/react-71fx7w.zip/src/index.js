import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';


const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
<div className="nav-wrapper">
<div className="nav">
  <button>HOME</button>
	<button>ABOUT</button>
	<button>WORK</button>
</div>
</div>

<div className="Header">
<p>Discover</p>
<p>Create</p>
<p>Engage</p>

</div>



  </React.StrictMode>  
);