import React from 'react';
import { useState } from 'react';

export default function ShoppingCart(props){
  const [count,setCount] = useState(0);

  const handleMinusClick = () => {
    if (count > 0) {
      setCount(count - 1);
      props.onSubtractFromSubtotal(props.price);
        }
  }

  const handlePlusClick = () => {
    setCount(count + 1);
    props.onAddtoSubtotal(props.price);
  }

  const [subtotal, setSubtotal] = useState(0);
  
  const handleAddtoSubtotal = (amount) => {
    setSubtotal(subtotal + amount);
  }

  const handleSubtractFromSubtotal = (amount) => {
    if (subtotal >= amount) {
      setSubtotal(subtotal - amount);
    }
  };
  
  return(
    <div className="container">
    <img className="image-size" src={props.itemsrc} alt={props.itemsrc + ' Clothing Merch '} id="item-1"/>
    <p>{props.itemcaption}<br/>$<span id="count1">{props.quantity}</span></p>
    <button onClick ={handleMinusClick}>-</button>
    <span>{count}</span>
    <button onCLick={handlePlusClick}>+</button>

    <div className="clearfloat"></div>
    <div id="content">
    <p><strong>Cart Subtotal:</strong>${subtotal}<span id="totalcount">0</span></p>
    </div>
    </div> 

    
   


  )
};