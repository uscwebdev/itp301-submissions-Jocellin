import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
const root = createRoot(document.querySelector('#root'));

root.render(
<React.StrictMode>

    <div id="center">
     <h1>Jocellin Cruz</h1>
     <a href="mailto:jocellin@usc.edu">jocellin@usc.edu</a>
     <p><button id="btn-click">favorite color</button></p>
    </div> 

    <div id="container">  

    <div className="column">
    <p>Favorite Website: <a href="https://www.autodraw.com/" target="_blank">autodraw</a></p>
    <img src="https://images.squarespace-cdn.com/content/v1/568ab2d4a2bab8527387c42c/1521690485828-QUSZ2WMD8GV1G52W2CO6/web+Faces+of+Santa+Ana-8334.jpg" alt="painting image">
    </div>
    
    <div className="column">
    <h2>Class Schedule</h2>
    <ol>
	     <li>DES 302: Design 3</li>
	     <li>DES 332A: Typography</li>
	     <li>ANTH 140: Mesoamerican Cosmovision and Culture</li>
	     <li>ITP 301: Front-End Web Development</li>
	     <li>ITP 310: Design for the User Experience</li>
    </ol>

</div>	
</div>

</React.StrictMode>  

)