import React from 'react';

export default function ShoppingCart(props){
  return(
    <div className="container">
    <img class="image-size" src={props.itemsrc} alt={props.itemsrc + ' Clothing Merch '} id="item-1"/>
    <p>{props.itemcaption}<br/>$<span id="count1">{props.quantity}</span></p>
    </div>   


  )
}