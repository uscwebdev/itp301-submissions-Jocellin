import React from 'react';

export default function Gallery(){
  const [src, setSrc] = useState(
    'https://i.pinimg.com/564x/89/1d/90/891d9094d4deea15375241ebeb9dd81a.jpg'
  );
  const [alt, setAlt] = useState('SZA');

  function handleImageChange(newSrc, newAlt) {
    console.log('Changing the image');
    setSrc(newSrc);
    setAlt(newAlt);
  }

  return (
    <div className="Thumbnail">
    <img  
    src={src}
    alt={alt} 
    onMouseEnter={() => {
      handleImageChange(
        'https://i.pinimg.com/564x/c2/25/0d/c2250d10adbb20c07e933c66874d833b.jpg',
        'Kali Uchis'
      );
      />
    <p><strong>Caption</strong></p>
  </div>
  </div>

  );
}

