import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
<h1>Photo Gallery</h1>

<div className="container">
<button>Image1</button>
<button>Image2</button>
<button>Image3</button>
<button>Image4</button>
<button>Image5</button>

<div className="Thumbnail">
  <img className="imagesize" src="https://i.pinimg.com/564x/89/1d/90/891d9094d4deea15375241ebeb9dd81a.jpg" />
  <p><strong>Caption</strong></p>
</div>
</div>


  </React.StrictMode>  
);