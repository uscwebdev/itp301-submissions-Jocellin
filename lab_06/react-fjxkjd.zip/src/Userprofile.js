import React from 'react';

export default function Userprofile(props){
  return(
<div className="thumbnail">

<img className="profilepic" src={props.profilesrc} alt={props.profilesrc + ' Profile Picture '} /> 
<h3>{props.username}</h3> 
<img className="thumbnailimg" src={props.postsrc} alt={props.caption + ' Post' }/>
<strong>{props.date}</strong>
<p>{props.caption}</p>

</div>
  );
}
