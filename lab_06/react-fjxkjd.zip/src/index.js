import React from 'react';
import { createRoot } from 'react-dom/client';
import Userprofile from './Userprofile.js';
import './index.css';

const root =  createRoot(document.querySelector("#root"));

root.render(
<React.StrictMode>


<h1>Art Forum</h1>

<div className="gallery">
<img className="images" src="https://i.pinimg.com/564x/33/ff/0b/33ff0b13ea7a09d68f3f90b911263de6.jpg" alt="drawing of a bowl of lemons" />
<img className="images" src="https://i.pinimg.com/564x/43/d6/f3/43d6f320b27642583ea1d90b6040e236.jpg" alt="painting of koi fish" />
<img className="images" src="https://i.pinimg.com/474x/96/da/42/96da420974b405eb746fa0cc74833a02.jpg" alt="drawing of flowers" />
</div>

<div className="content">
<p> Hello! Welcome to the Art Forum, a place for creatives to share their art and engage with other creative people. Users can upload and showcase their artwork ranging from paintings and drawings to digital designs and photography!</p> 
<p> Beyond individual expression, The Art Forum is a great way to collaborate and potentially meet other artists. Artist can come together to collabrate on projects, wether its painting a mural, a multimedia exhibiton, or a cute doodle contest, the possibiites are endless. Through shared workspaces, and discussion forum, users can brainstorm ideas, exchange feedback, and bring their collective visions to life. </p> 
<p> Artists can explore a vast library of artwork, find inspiration, and learn from the techniques and experiences of others. Wether you're a professional or just starting your art journey, the platform is a space where artists can receive constructive feedback and ecnourgament, helping them refine their skills and reach their new heights in their artistic endeavors!  </p> 
<p>Warm up by clicking <a href="https://www.autodraw.com/" target="_blank"> HERE</a> to draw some quick doodles</p>
</div>
{/*}
<div className="thumbnail">
<img className="profilepic" src="https://i.pinimg.com/564x/e3/e8/df/e3e8df1e56e1c8839457b42bdcd750e5.jpg" alt="picture of avatar" /> 
<h3>Artlover2002</h3> 
<img className="thumbnailimg" src="https://i.pinimg.com/474x/55/7a/0e/557a0ee85475cc62f756d6651e0d498b.jpg" alt="drawing of flower"/>
<strong>9/25/2023</strong>
<p>Warm color palette </p>
</div> */}

<Userprofile 
profilesrc="https://i.pinimg.com/564x/e3/e8/df/e3e8df1e56e1c8839457b42bdcd750e5.jpg" 
username= "Artlover2002" 
postsrc="https://i.pinimg.com/474x/55/7a/0e/557a0ee85475cc62f756d6651e0d498b.jpg" 
date="9/25/2023" 
caption="Warm color palette"/>

<Userprofile 
profilesrc="https://i.pinimg.com/474x/e6/6d/0f/e66d0f10776c83128e4fc46217b06e2f.jpg" 
username= "SweetLocuras" 
postsrc="https://i.pinimg.com/564x/51/fb/76/51fb76c6c545a578eede28dfdf2d363b.jpg" 
date="9/25/2023" 
caption="Painting of the moon and lady"/>

<Userprofile 
profilesrc="https://i.pinimg.com/474x/33/d5/c5/33d5c5aff087511af295037d8b22d211.jpg" 
username= "Bob_The_Painter" 
postsrc="https://i.pinimg.com/736x/cb/92/79/cb927949c9398705eae798a887f162e7.jpg" 
date="9/25/2023" 
caption="Fruit painting"/>

<Userprofile 
profilesrc="https://i.pinimg.com/474x/40/a4/2f/40a42f4b27a14089b82a916aaff0b298.jpg" 
username= "VanGoghWannaBe" 
postsrc="https://i.pinimg.com/564x/7b/22/bc/7b22bc575ff3c6bc08e8fd5dca86da96.jpg" 
date="9/25/2023" 
caption="A pretty pond with pretty lily pads"/>


</React.StrictMode>  

);


